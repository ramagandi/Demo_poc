int main()
{
int a;
char a[10];
a[10] = 0;
return 0;
}